var express = require('express')
var app = express()
express
app.listen(3000, function(){
    console.log("Servidor com express foi carregado")
})